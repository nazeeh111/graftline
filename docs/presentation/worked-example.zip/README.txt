# Graftline actual closed-execution example

Exact main13261db3cf8778157398295f221aac93f975531a. Python3.10+ standard library is sufficient. No original native library is included or needed. From this fresh extracted directory choose new output names:

    python3 -I -S run.py run features/zstd features/zstd/example.zst decoded-new.bin --param capacity=150000
    python3 -I -S run.py run features/utf8proc features/utf8proc/example.txt normalized-new.txt --param options=1070

Compare decoded-new.bin with zstd-output.bin, normalized-new.txt with unicode-output.txt and MANIFEST.json. The actual output hashes and full declared ABIs are in journey.json. Existing outputs refuse overwriting.
To check the current stored Unicode receipt on the same Python identity:

    python3 -I -S run.py verify features/utf8proc features/utf8proc/cases.json --check-receipt unicode-receipt.json

Python version is part of receipt identity. A different Python version can still run the feature but should create a new receipt with --receipt NEW.json rather than relabel this record. Both original receipts are retained and were made with the Python identity in their metadata. Source and licenses must remain stable during verification.
Both original library filesystem paths in feature.json are historical provenance; they are not bundle dependencies or instructions to access the original library. Extraction is a separate operation and no extraction tools are needed or included here.
All MANIFEST.json members are included. Project runtime/tools MIT; modified extracted Zstandard code/data BSD; utf8proc/Unicode keep their included notices. Preserve LICENSE and both feature LICENSE files. No upstream endorsement, universal decoder/Unicode parity, minimal transplant, complete memory-safety proof or arbitrary native binary support is claimed.
